<?php
include("../../../conn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $curriculum_name = mysqli_real_escape_string($conn, $_POST['curriculum_name']);
    $curriculum_course = mysqli_real_escape_string($conn, $_POST['curriculum_course']);
    $curriculum_year = mysqli_real_escape_string($conn, $_POST['curriculum_year']);


    // Use prepared statements to prevent SQL injection
    $sql_insert = "INSERT INTO curriculum_tbl (curriculum_name, curriculum_course, curriculum_year) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql_insert);

    // Bind parameters to the prepared statement
    mysqli_stmt_bind_param($stmt, "sss", $curriculum_name, $curriculum_course, $curriculum_year);

    // Execute the statement
    $insert_query = mysqli_stmt_execute($stmt);

    // Check for errors
    if (!$insert_query) {
        die('Query Error: ' . mysqli_stmt_error($stmt));
    }

    header("Location: curriculum.php");
    exit();
}


